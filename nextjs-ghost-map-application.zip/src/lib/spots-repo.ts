import { readFile } from "node:fs/promises";
import path from "node:path";
import {
  and,
  asc,
  desc,
  eq,
  gte,
  ilike,
  inArray,
  or,
  sql,
  type SQL,
} from "drizzle-orm";
import { db } from "@/db";
import { spots, type NewSpotRow, type SpotRow } from "@/db/schema";
import type {
  SpotCollection,
  SpotFacets,
  SpotFeature,
  SpotProperties,
} from "@/lib/types";

const GEOJSON_PATH = path.join(process.cwd(), "data", "spots.geojson");

type RawFeature = {
  geometry: { coordinates: [number, number] };
  properties: SpotProperties;
};

let seedPromise: Promise<void> | null = null;

async function readGeoJson(): Promise<RawFeature[]> {
  const raw = await readFile(GEOJSON_PATH, "utf8");
  const parsed = JSON.parse(raw) as { features: RawFeature[] };
  return parsed.features ?? [];
}

async function tableReady(): Promise<boolean> {
  try {
    await db.execute(sql`select 1 from ${spots} limit 1`);
    return true;
  } catch {
    return false;
  }
}

async function createTableIfMissing() {
  try {
    await db.execute(sql`
    create table if not exists "spots" (
      "spotcd" integer primary key,
      "name" text not null,
      "kana" text,
      "address" text,
      "prefecture" text,
      "city" text,
      "lat" double precision not null,
      "lng" double precision not null,
      "genre" text,
      "status" text,
      "phenomena" text[] not null default '{}',
      "features" text[] not null default '{}',
      "total_score" integer,
      "national_rank" integer,
      "pref_rank" integer,
      "fear_rating" real,
      "rating_count" integer,
      "outline" text,
      "comment" text,
      "image_url" text,
      "source_url" text not null,
      "updated_at" timestamptz not null default now()
    )
    `);
    await db.execute(
      sql`create index if not exists "spots_pref_idx" on "spots" ("prefecture")`,
    );
    await db.execute(
      sql`create index if not exists "spots_genre_idx" on "spots" ("genre")`,
    );
    await db.execute(
      sql`create index if not exists "spots_bbox_idx" on "spots" ("lat","lng")`,
    );
  } catch (error) {
    // 並列プロセスが同時に CREATE TABLE した場合の競合は無視して続行
    const code = (error as { code?: string }).code;
    if (code !== "23505" && code !== "42P07" && code !== "42P16") throw error;
  }
}

function toRow(f: RawFeature): NewSpotRow {
  const p = f.properties;
  return {
    spotcd: p.spotcd,
    name: p.name,
    kana: p.kana ?? null,
    address: p.address ?? null,
    prefecture: p.prefecture ?? null,
    city: p.city ?? null,
    lat: f.geometry.coordinates[1],
    lng: f.geometry.coordinates[0],
    genre: p.genre ?? null,
    status: p.status ?? null,
    phenomena: p.phenomena ?? [],
    features: p.features ?? [],
    totalScore: p.totalScore ?? null,
    nationalRank: p.nationalRank ?? null,
    prefRank: p.prefRank ?? null,
    fearRating: p.fearRating ?? null,
    ratingCount: p.ratingCount ?? null,
    outline: p.outline ?? null,
    comment: p.comment ?? null,
    imageUrl: p.imageUrl ?? null,
    sourceUrl: p.sourceUrl,
  };
}

/** GeoJSON から DB へ upsert（冪等） */
export async function importGeoJsonIntoDb(): Promise<number> {
  await createTableIfMissing();
  const features = await readGeoJson();
  const rows = features.map(toRow);
  const chunk = 250;
  for (let i = 0; i < rows.length; i += chunk) {
    await db
      .insert(spots)
      .values(rows.slice(i, i + chunk))
      .onConflictDoUpdate({
        target: spots.spotcd,
        set: {
          name: sql`excluded.name`,
          kana: sql`excluded.kana`,
          address: sql`excluded.address`,
          prefecture: sql`excluded.prefecture`,
          city: sql`excluded.city`,
          lat: sql`excluded.lat`,
          lng: sql`excluded.lng`,
          genre: sql`excluded.genre`,
          status: sql`excluded.status`,
          phenomena: sql`excluded.phenomena`,
          features: sql`excluded.features`,
          totalScore: sql`excluded.total_score`,
          nationalRank: sql`excluded.national_rank`,
          prefRank: sql`excluded.pref_rank`,
          fearRating: sql`excluded.fear_rating`,
          ratingCount: sql`excluded.rating_count`,
          outline: sql`excluded.outline`,
          comment: sql`excluded.comment`,
          imageUrl: sql`excluded.image_url`,
          sourceUrl: sql`excluded.source_url`,
          updatedAt: sql`now()`,
        },
      });
  }
  return rows.length;
}

/** 初回アクセス時にテーブルが空ならシードする */
export async function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = (async () => {
      if (!(await tableReady())) {
        await createTableIfMissing();
      }
      // 複数プロセス（ビルドワーカー等）の同時シードを防ぐ (transaction scoped lock)
      await db.transaction(async (tx) => {
        await tx.execute(sql`select pg_advisory_xact_lock(918273645)`);
        const [row] = await tx
          .select({ c: sql<number>`count(*)::int` })
          .from(spots);
        if (!row || row.c === 0) await importGeoJsonIntoDb();
      });
    })().catch((err) => {
      seedPromise = null;
      throw err;
    });
  }
  return seedPromise;
}

export type SpotQuery = {
  bbox?: [number, number, number, number]; // minLng,minLat,maxLng,maxLat
  genre?: string[];
  pref?: string[];
  phenomenon?: string;
  minRating?: number;
  q?: string;
  limit?: number;
};

export function rowToFeature(row: SpotRow): SpotFeature {
  return {
    type: "Feature",
    geometry: { type: "Point", coordinates: [row.lng, row.lat] },
    properties: {
      spotcd: row.spotcd,
      name: row.name,
      kana: row.kana,
      address: row.address,
      prefecture: row.prefecture,
      city: row.city,
      genre: row.genre,
      status: row.status,
      phenomena: row.phenomena ?? [],
      features: row.features ?? [],
      totalScore: row.totalScore,
      nationalRank: row.nationalRank,
      prefRank: row.prefRank,
      fearRating: row.fearRating,
      ratingCount: row.ratingCount,
      outline: row.outline,
      comment: row.comment,
      imageUrl: row.imageUrl,
      sourceUrl: row.sourceUrl,
    },
  };
}

function buildConditions(query: SpotQuery): SQL[] {
  const conds: SQL[] = [];
  if (query.bbox) {
    const [minLng, minLat, maxLng, maxLat] = query.bbox;
    conds.push(
      sql`${spots.lat} between ${Math.min(minLat, maxLat)} and ${Math.max(minLat, maxLat)}`,
    );
    conds.push(
      sql`${spots.lng} between ${Math.min(minLng, maxLng)} and ${Math.max(minLng, maxLng)}`,
    );
  }
  if (query.genre?.length) {
    conds.push(inArray(spots.genre, query.genre));
  }
  if (query.pref?.length) {
    conds.push(inArray(spots.prefecture, query.pref));
  }
  if (query.phenomenon) {
    conds.push(sql`${query.phenomenon} = any(${spots.phenomena})`);
  }
  if (typeof query.minRating === "number" && query.minRating > 0) {
    conds.push(gte(spots.fearRating, query.minRating));
  }
  if (query.q) {
    const like = `%${query.q}%`;
    const orCond = or(
      ilike(spots.name, like),
      ilike(spots.kana, like),
      ilike(spots.address, like),
      ilike(spots.city, like),
      ilike(spots.prefecture, like),
    );
    if (orCond) conds.push(orCond);
  }
  return conds;
}

export async function querySpots(query: SpotQuery): Promise<SpotCollection> {
  await ensureSeeded();
  const limit = Math.min(query.limit ?? 1500, 3000);
  const conds = buildConditions(query);
  const rows = await db
    .select()
    .from(spots)
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(desc(spots.totalScore), asc(spots.spotcd))
    .limit(limit + 1);

  const truncated = rows.length > limit;
  const page = truncated ? rows.slice(0, limit) : rows;
  return {
    type: "FeatureCollection",
    count: page.length,
    truncated,
    features: page.map(rowToFeature),
  };
}

export async function getSpot(spotcd: number): Promise<SpotFeature | null> {
  await ensureSeeded();
  const [row] = await db
    .select()
    .from(spots)
    .where(eq(spots.spotcd, spotcd))
    .limit(1);
  return row ? rowToFeature(row) : null;
}

export async function getNearby(
  spotcd: number,
  lat: number,
  lng: number,
  limit = 4,
): Promise<SpotFeature[]> {
  const rows = await db
    .select()
    .from(spots)
    .where(sql`${spots.spotcd} <> ${spotcd}`)
    .orderBy(
      sql`((${spots.lat} - ${lat}) * (${spots.lat} - ${lat}) + (${spots.lng} - ${lng}) * (${spots.lng} - ${lng}))`,
    )
    .limit(limit);
  return rows.map(rowToFeature);
}

export async function getFacets(): Promise<SpotFacets> {
  await ensureSeeded();
  const genres = await db
    .select({ value: spots.genre, count: sql<number>`count(*)::int` })
    .from(spots)
    .where(sql`${spots.genre} is not null`)
    .groupBy(spots.genre)
    .orderBy(sql`count(*) desc`);
  const prefectures = await db
    .select({ value: spots.prefecture, count: sql<number>`count(*)::int` })
    .from(spots)
    .where(sql`${spots.prefecture} is not null`)
    .groupBy(spots.prefecture)
    .orderBy(sql`count(*) desc`);
  const phenomena = await db.execute<{ value: string; count: number }>(sql`
    select unnest(phenomena) as value, count(*)::int as count
    from ${spots}
    group by 1
    order by count desc
    limit 24
  `);
  const [total] = await db.select({ c: sql<number>`count(*)::int` }).from(spots);

  return {
    total: total?.c ?? 0,
    genres: genres.map((g) => ({ value: g.value ?? "その他", count: g.count })),
    prefectures: prefectures.map((p) => ({
      value: p.value ?? "不明",
      count: p.count,
    })),
    phenomena: (phenomena.rows ?? []).map((r) => ({
      value: r.value,
      count: Number(r.count),
    })),
  };
}
