/**
 * data/spots.geojson を PostgreSQL (Drizzle) へ取り込む。
 *   npx tsx scripts/seed.ts
 */
import "dotenv/config";
import { importGeoJsonIntoDb } from "../src/lib/spots-repo";
import { pool } from "../src/db";

async function main() {
  const count = await importGeoJsonIntoDb();
  console.log(`✅ ${count} 件のスポットを DB に取り込みました`);
  await pool.end();
}

main().catch(async (err) => {
  console.error(err);
  process.exit(1);
});
